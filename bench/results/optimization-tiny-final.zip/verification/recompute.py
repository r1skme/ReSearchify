#!/usr/bin/env python3
"""Recompute the retained final tiny benchmark evidence without running targets."""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics

EXPECTED = {"term": 1, "literal": 1, "broad_term": 100000,
            "broad_regex": 100000, "anchored_regex": 100000, "missing_term": 0}
STAGES = ("strict_noop", "global_one_edit", "targeted_one_edit", "targeted_one_add", "targeted_one_delete")

def dist(values):
    ordered = sorted(values)
    assert ordered and all(math.isfinite(x) for x in ordered)
    return {"iterations": len(values), "median": statistics.median(values),
            "p95": ordered[math.ceil(.95 * len(values)) - 1], "min": ordered[0], "max": ordered[-1]}

def compact(value):
    if isinstance(value, dict):
        return {k: compact(v) for k, v in value.items() if k not in ("samples", "raw")}
    if isinstance(value, list):
        return [compact(v) for v in value]
    return value

def assert_distribution(saved, samples=None):
    values = saved["samples"] if samples is None else samples
    assert saved["samples"] == values
    result = dist(values)
    assert all(saved[k] == v for k, v in result.items()), (saved, result)
    return result

def all_distributions(value):
    count = 0
    if isinstance(value, dict):
        if {"iterations", "median", "p95", "min", "max", "samples"} <= value.keys():
            assert_distribution(value)
            count += 1
        count += sum(all_distributions(v) for v in value.values())
    elif isinstance(value, list):
        count += sum(all_distributions(v) for v in value)
    return count

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.results
    raw = {p.name: json.loads(p.read_text(encoding="utf-8")) for p in sorted(root.glob("*.json"))}
    distributions = sum(all_distributions(value) for value in raw.values())
    summary = raw["summary.json"]
    assert summary["format"] == "researchify-tiny-comparison-v1" and summary["complete"]
    assert summary["fixture"]["files"] == 100000 and summary["fixture"]["lines"] == 800000
    assert summary["fixture"]["bytes"] == 19034450
    assert summary["fixture"]["path_and_content_sha256"] == "d99f3d069ea6e58538a16f3080656292ac29bc4f325162ea5576ffa255e3d2dd"
    hashes = {k: v["sha256"] for k, v in summary["binaries"].items()}
    assert hashes["baseline"] == "b0a2c90c2dcaa3a71993751ec895807f32e8959e7439397971880564087e9154"
    assert hashes["current"] == "701c8a34f6578e212336e80628bdd711df6413d6c8f1e0edf7d8b58f8a4b1293"
    builds = []
    assert len(summary["builds"]) == 4
    for row in summary["builds"]:
        sample = row["sample"]
        response = json.loads(sample["stdout"])
        assert sample["returncode"] == 0 and not sample["stderr"]
        assert response["status"] == "ok" and response["execution_complete"]
        assert all(response[k] == summary["fixture"][k] for k in ("files", "bytes", "lines"))
        assert response["workers"] == 8 and response["segments"] == 16
        assert row["command"][row["command"].index("--threads") + 1] == "8"
        builds.append({k: row[k] for k in ("writer", "profile", "command", "storage")}
                      | {"sample": {k: v for k, v in sample.items() if k not in ("stdout", "stderr")}, "response": response})
    correctness = summary["correctness"]
    assert len(correctness) == 24
    assert {(r["profile"], r["tool"], r["case"]) for r in correctness} == {
        (p, t, c) for p in ("compact", "fast") for t in ("baseline", "current") for c in EXPECTED}
    for row in correctness:
        assert row["status"] == "passed" and row["matching_files"] == EXPECTED[row["case"]]
        assert len(row["sampled_actual_hits"]) == min(16, EXPECTED[row["case"]])
    for case in EXPECTED:
        assert len({r["path_counts_sha256"] for r in correctness if r["case"] == case}) == 1
    result = {"format": "researchify-tiny-final-summary-v1", "complete": True,
              "source_report": "results/summary.json", "fixture": summary["fixture"],
              "platform": summary["platform"], "machine": summary["machine"], "logical_cpus": summary["logical_cpus"],
              "binaries": summary["binaries"], "ripgrep": summary["ripgrep"], "conditions": summary["conditions"],
              "builds": builds, "correctness": correctness, "process": {}, "sessions": {}, "updates": {}}
    operations = checks = audits = 0
    for profile in ("compact", "fast"):
        process = raw[profile + "-process.json"]
        assert process["complete"] and process["iterations"] == 21
        assert {r["name"] for r in process["queries"]} == set(EXPECTED)
        assert {k: v["sha256"] for k, v in process["binaries"].items()} == hashes
        process_rows = []
        for row in process["queries"]:
            assert row["matching_files"] == EXPECTED[row["name"]]
            assert len(row["order"]) == 21 and all(set(order) == {"baseline", "current", "rg"} for order in row["order"])
            for tool in row["tools"].values():
                assert all(tool[k]["iterations"] == 21 for k in ("wall_ms", "cpu_ms", "peak_rss_bytes"))
            work = {}
            for name, values in row["engine_metrics"].items():
                assert len(values) == 21
                work[name] = {field: sorted({v[field] for v in values}) for field in ("candidates", "scanned_bytes")}
            before, after = (row["tools"][name]["wall_ms"]["samples"] for name in ("baseline", "current"))
            process_rows.append({k: row[k] for k in ("name", "query", "matching_files", "commands")}
                                | {"tools": compact(row["tools"]), "work": work,
                                   "paired_wall_speedup_recomputed": dist([b / a for b, a in zip(before, after)]),
                                   "ratio_of_wall_medians": statistics.median(before) / statistics.median(after),
                                   "current_faster_pairs": sum(b > a for b, a in zip(before, after))})
        result["process"][profile] = {"conditions": process["conditions"], "indexes": process["indexes"], "queries": process_rows}

        session = raw[profile + "-sessions.json"]
        assert session["complete"] and session["index_path"].endswith("current-" + profile)
        assert {row["name"] for row in session["queries"]} == {"term", "literal"}
        assert {k: v["sha256"] for k, v in session["binaries"].items()} == hashes
        session_rows = []
        for row in session["queries"]:
            n = 1000 if row["name"] == "term" else 21
            assert len(row["paired_order"]) == n and all(set(order) == {"baseline", "current"} for order in row["paired_order"])
            for name, tool in row["tools"].items():
                values = tool["raw"]
                assert len(values) == n
                assert_distribution(tool["request_wall_ms"], [x["request_wall_seconds"] * 1000 for x in values])
                assert_distribution(tool["engine_wall_ms"], [x["engine_seconds"] * 1000 for x in values])
                for value in [row["first_request"][name], *row["warmups"][name], *values]:
                    response = value["response"]
                    assert response["status"] == "ok" and response["execution_complete"]
                    assert response["total"] == EXPECTED[row["name"]] and not response["output_truncated"]
                    assert response["results"] == []
            before = row["tools"]["baseline"]["raw"]
            after = row["tools"]["current"]["raw"]
            session_rows.append({"name": row["name"], "query": row["query"], "request": row["request"],
                                 "tools": compact(row["tools"]),
                                 "paired_request_speedup_recomputed": dist([b["request_wall_seconds"] / a["request_wall_seconds"] for b, a in zip(before, after)]),
                                 "ratio_of_request_medians": row["tools"]["baseline"]["request_wall_ms"]["median"] / row["tools"]["current"]["request_wall_ms"]["median"]})
        result["sessions"][profile] = {"conditions": session["conditions"], "index_path": session["index_path"], "queries": session_rows}

        update = raw[profile + "-updates.json"]
        assert update["complete"] and update["source_restored"]
        assert update["conditions"]["threads"] == 8 and update["conditions"]["memory_mb"] == 256
        assert len(update["operations"]) == 70 and len(update["checks"]) == 46 and len(update["mutation_audit"]) == 49
        assert update["binaries"]["baseline"]["sha256"] == hashes["baseline"]
        assert update["binaries"]["candidate"]["sha256"] == hashes["current"]
        assert update["base_index"].endswith("current-" + profile)
        for check in update["checks"]:
            if "results" in check:
                assert check["results"]["baseline"] == check["results"]["candidate"]
            else:
                assert check["operation"] in ("rename", "verify") and check["response"]["execution_complete"]
                assert check["response"]["status"] == "ok" and check["response"]["files"] == 100000
                if check["operation"] == "rename":
                    assert check["response"]["added"] == 1 and check["response"]["removed"] == 1
                    assert not check["response"]["global_scan"]
        first, last = update["mutation_audit"][0], update["mutation_audit"][-1]
        assert first["event"] == "initial" and last["event"] == "after_restore"
        assert all(first[k] == last[k] for k in ("sha256", "bytes", "mtime_ns"))
        update_rows = []
        for row in update["summaries"]:
            stage = row["stage"]
            assert stage in STAGES
            by_tool = {}
            work = {}
            for name in ("baseline", "candidate"):
                records = [v for v in update["operations"] if v["stage"] == stage and v["binary"] == name]
                assert len(records) == 7 and [v["iteration"] for v in records] == list(range(7))
                by_tool[name] = [v["sample"] for v in records]
                for v in records:
                    assert v["sample"]["returncode"] == 0 and not v["sample"]["stderr"]
                    assert v["response"]["status"] == "ok" and v["response"]["execution_complete"]
                    assert json.loads(v["sample"]["stdout"]) == v["response"]
                for metric, key, factor in (("wall_ms", "wall_seconds", 1000), ("cpu_ms", "cpu_seconds", 1000), ("peak_rss_bytes", "peak_rss_bytes", 1)):
                    assert_distribution(row["tools"][name][metric], [v["sample"][key] * factor for v in records])
                work[name] = {k: sorted({v["response"][k] for v in records}) for k in ("global_scan", "hashed", "tokenized", "workers", "added", "changed", "removed")}
                assert work[name]["global_scan"] == [stage in ("strict_noop", "global_one_edit")]
                assert work[name]["hashed"] == [100000 if stage in ("strict_noop", "global_one_edit") else 0 if stage == "targeted_one_delete" else 1]
            ratios = [b["wall_seconds"] / a["wall_seconds"] for b, a in zip(by_tool["baseline"], by_tool["candidate"])]
            assert_distribution(row["paired_wall_speedup"], ratios)
            assert row["candidate_faster_pairs"] == sum(v > 1 for v in ratios)
            update_rows.append(compact(row) | {"work": work})
        assert {r["stage"] for r in update_rows} == set(STAGES)
        operations += len(update["operations"]); checks += len(update["checks"]); audits += len(update["mutation_audit"])
        result["updates"][profile] = {"conditions": update["conditions"], "base_index": update["base_index"],
                                      "source_restored": True, "initial_edit": first, "restored_edit": last, "summaries": update_rows}
    assert len(summary["sequential_process_batches"]) == 5
    for row in summary["sequential_process_batches"]:
        assert row["iterations"] == 1000 and row["individual_process_wall_ms"]["iterations"] == 1000
        assert row["batch_wall_seconds"] * 1000 >= sum(row["individual_process_wall_ms"]["samples"])
    result["sequential_process_batches"] = compact(summary["sequential_process_batches"])
    result["validation"] = {"stored_distributions_recomputed_exactly": distributions, "full_path_count_checks": 24,
                            "snippet_sampled_file_result_records": sum(len(r["sampled_actual_hits"]) for r in correctness),
                            "fresh_process_tool_samples": 2 * 6 * 21 * 3,
                            "jsonl_term_pairs_per_profile": 1000, "jsonl_literal_pairs_per_profile": 21,
                            "sequential_cli_blocks": 5, "processes_per_block": 1000,
                            "update_operations": operations, "update_correctness_records": checks, "mutation_audit_events": audits,
                            "method": "Independent stdlib recomputation of every stored median/p95/min/max/sample count, raw JSONL timings and update sample-to-summary values; no target execution or source/index mutation"}
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result["validation"]))

if __name__ == "__main__":
    main()
