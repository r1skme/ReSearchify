#!/usr/bin/env python3
"""One-off reproducible preparation, never included in target search timings."""
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time

REPO = Path('/workspace/scratch/93bfa6b783da/ReSearchify-cache-benchmark')
ROOT = Path('/workspace/scratch/93bfa6b783da')
sys.path.insert(0, str(REPO / 'scripts'))
import perf_benchmark as bench

mode = sys.argv[1]
assert mode in ('smoke', 'main')
work = Path(__file__).resolve().parent / mode
work.mkdir(exist_ok=False)
fixture = work / 'fixture'
source = fixture / 'source'
count = 64 if mode == 'smoke' else 100000
binaries = {
    'baseline': ROOT / 'ReSearchify-baseline/build/rs',
    'current': ROOT / 'rs-final-integrated',
}
expected = {
    'baseline': 'b0a2c90c2dcaa3a71993751ec895807f32e8959e7439397971880564087e9154',
    'current': '701c8a34f6578e212336e80628bdd711df6413d6c8f1e0edf7d8b58f8a4b1293',
}
report = {'format': 'researchify-cache-preparation-v1', 'complete': False,
          'mode': mode, 'setup_excluded_from_search_timings': True,
          'source_revisions': {'baseline': 'eb858348169157686e70104af6b64f9539a39fe8',
                               'current': '228220743f205c370964fcb4475c8daee1f4b3b7'},
          'builds': {}, 'fixture': str(fixture)}
start = time.perf_counter()


def save():
    (work / 'preparation.json').write_text(json.dumps(report, indent=2) + '\n')


def command(argv):
    result = bench.command([str(a) for a in argv], 1800)
    if result['returncode'] or result['stderr']:
        raise RuntimeError(result['stdout'] + result['stderr'])
    return {'argv': [str(a) for a in argv], 'measurement': result}


try:
    for name, binary in binaries.items():
        digest = bench.binary_identity(str(binary))
        if digest != expected[name]:
            raise RuntimeError('Unexpected binary hash: ' + name)
    report['binary_sha256'] = expected
    if mode == 'smoke':
        report['generation'] = command([sys.executable, REPO / 'scripts/generate_tiny_corpus.py',
                                        '--work', fixture, '--files', str(count)])
        report['pristine_generator_manifest'] = json.loads((fixture / 'fixture.json').read_text())
        edit = source / 'group_0/module_42.cpp'
        original = edit.read_bytes()
        old = b'int common = needle_42;\n'
        new = b'int common = needle_42 + needle_42;\n'
        if original.count(old) != 1:
            raise RuntimeError('Unexpected smoke source')
        updated = original.replace(old, new)
        edit.write_bytes(updated)
        report['augmentation'] = {'file': 'group_0/module_42.cpp',
                                  'before_sha256': hashlib.sha256(original).hexdigest(),
                                  'after_sha256': hashlib.sha256(updated).hexdigest(),
                                  'description': 'One existing line has two needle_42 occurrences; term matches=3, broad-regex matching lines=2; all files retain eight lines.'}
    else:
        generator = ROOT / 'ReSearchify/build/cs_bench'
        report['generation_binary_sha256'] = bench.binary_identity(str(generator))
        report['generation'] = command([generator, '--phase', 'generate', '--work', fixture,
                                        '--files', str(count), '--lines', '50'])
    digest = hashlib.sha256()
    total_bytes = total_lines = 0
    for number in range(count):
        relative = f'group_{number // 1000}/module_{number}.cpp'
        data = (source / relative).read_bytes()
        total_bytes += len(data)
        total_lines += data.count(b'\n')
        digest.update(relative.encode('ascii') + b'\0' + data + b'\0')
    corpus = {'format': 'researchify-cache-corpus-v1', 'kind': 'synthetic-surrogate',
              'files': count, 'lines': total_lines, 'bytes': total_bytes,
              'path_and_content_sha256': digest.hexdigest(), 'digest_order': 'numeric module number',
              'description': 'Owned generated fixture, not a user corpus',
              'augmentation': report.get('augmentation')}
    (fixture / 'fixture.json').write_text(json.dumps(corpus, indent=2) + '\n')
    report['corpus'] = corpus
    save()
    print(json.dumps({'phase': 'generated', 'mode': mode, 'corpus': corpus}), flush=True)
    for name, binary in binaries.items():
        report['builds'][name] = command([binary, 'create', '--root', source,
                                         '--index', fixture / (name + '-compact'),
                                         '--profile', 'compact', '--threads', '4',
                                         '--memory-mb', '256', '--json'])
        save()
        print(json.dumps({'phase': 'built', 'name': name,
                          'wall_seconds': report['builds'][name]['measurement']['wall_seconds']}), flush=True)
    marker = {'format': 'researchify-cache-fixture-v1', 'disposable': True,
              'description': f'Owned generated {count}-file cache fixture; not a user corpus; ' +
                             ('eight lines with documented same-line smoke duplication' if mode == 'smoke' else '50 lines per file, original cs_bench generator unchanged'),
              'source': 'source', 'indexes': {'baseline': 'baseline-compact', 'current': 'current-compact'},
              'corpus_manifest': 'fixture.json', 'corpus_manifest_sha256': bench.binary_identity(str(fixture / 'fixture.json'))}
    (fixture / 'cache-fixture.json').write_text(json.dumps(marker, indent=2) + '\n')
    # Only these owned fixture files; never global sync or device-cache reset.
    clean_start, cleaned, errors = time.perf_counter(), 0, []
    for directory in (source, fixture / 'baseline-compact', fixture / 'current-compact'):
        for parent, dirs, names in os.walk(directory):
            if Path(parent) == directory:
                dirs[:] = [name for name in dirs if name != 'pins']
            for name in names:
                if name in ('writer.lock', 'access.lock'):
                    continue
                path = Path(parent) / name
                info = path.lstat()
                if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_nlink != 1:
                    raise RuntimeError('Unowned/nonregular preparation file: ' + str(path))
                fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
                try:
                    if os.fstat(fd).st_ino != info.st_ino:
                        raise RuntimeError('Preparation file identity changed')
                    os.fdatasync(fd)
                    cleaned += 1
                except OSError as error:
                    errors.append({'path': str(path), 'error': str(error)})
                finally:
                    os.close(fd)
    report['scoped_data_cleaning'] = {'method': 'fdatasync each owned fixture source/index file; no global sync',
                                     'files_cleaned': cleaned, 'errors': errors,
                                     'wall_seconds': time.perf_counter() - clean_start}
    report['wall_seconds'] = time.perf_counter() - start
    report['complete'] = True
    save()
    print(json.dumps({'phase': 'prepared', 'mode': mode, 'work': str(work), 'wall_seconds': report['wall_seconds'],
                      'scoped_data_cleaning': report['scoped_data_cleaning']}), flush=True)
except BaseException as error:
    report['error'] = type(error).__name__ + ': ' + str(error)
    save()
    raise
